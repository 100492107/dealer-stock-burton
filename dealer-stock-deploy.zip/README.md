# Dealer Stock Manager (Burton)

Shared stock list for **Pentagon Burton Upon Trent**, auto-synced from the public website twice a day.

## Deploy on GitHub + Vercel (recommended)

### 1. Create a GitHub repo
1. Go to https://github.com/new
2. Name it e.g. `dealer-stock-burton` (public or private)
3. Do **not** add a README (this folder already has one)
4. Create the repo

### 2. Upload this folder
**Option A – website (easiest)**  
- Open the new repo → **Add file → Upload files**  
- Drag everything from this `dealer-stock` folder  
- Commit

**Option B – terminal**
```bash
cd dealer-stock
git init
git add .
git commit -m "Initial dealer stock app"
git branch -M main
git remote add origin https://github.com/YOUR_USER/dealer-stock-burton.git
git push -u origin main
```

### 3. Deploy on Vercel
1. Go to https://vercel.com → sign in with **GitHub**
2. **Add New Project** → import `dealer-stock-burton`
3. Framework: **Other** (static) — leave defaults
4. Deploy

You get a link like:
`https://dealer-stock-burton.vercel.app`

Share that with colleagues and managers. Everyone sees the same stock.

### 4. Keep stock updated (twice daily)
Grok automations already run at **09:00** and **18:00** (London time) and refresh data in this project.

To publish those updates live:
1. After each sync, push the updated `vehicles.json` (and `index.html`) to GitHub
2. Vercel redeploys automatically in about 30 seconds

Or ask Grok: "sync Burton stock and push to GitHub" once the repo is connected.

## How it works
| File | Role |
|------|------|
| `index.html` | The app (list, search, stock cards, notes) |
| `vehicles.json` | Live stock data — loaded by every device |
| `sync_burton.py` | Scrapes Pentagon Burton used cars |
| `vercel.json` | Cache rules so stock is not stale |

## Notes
- Opening `index.html` as a local file **cannot** auto-update or be shared — always use the Vercel link.
- Manual edits (notes, status flags) stay on each browser unless you set up cloud Sync (JSONBin) inside the app.
